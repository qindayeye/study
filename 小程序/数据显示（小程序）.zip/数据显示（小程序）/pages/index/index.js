Page({

  data: {
    KG: "0",
    humidity: "0",
    userN: '', // 设备ID
    passW: '', // api-key
    myTime: null // 定时器
  },


  // 用户名和密码输入框事件
  userNameInput: function(e) {
    this.setData({
      userN: e.detail.value
    })
    console.log(e.detail.value)
    console.log(this.data.userN)
  },
  passWdInput: function(e) {
    this.setData({
      passW: e.detail.value
    })
  },

  //登录按钮点击事件，调用参数要用：this.data.参数；
  //设置参数值，要使用this.setData({}）方法
  loginBtnClick: function () {

    this.data.myTime = setInterval(function() {
      this.init(this.data.userN, this.data.passW) //不断获取继电器状态
    }.bind(this), 500)

  },
  resetBtnClick: function() {
    clearInterval(this.data.myTime)
    this.setData({
      passW: '',
      userN: '',
      KG: 0,
      humidity: 0
    })

  },


  // //周期函数
  // onLoad: function () {
  //   setInterval(function () {
  //     this.init() //不断获取继电器状态
  //   }.bind(this), 500)
  // },

  //用于获取继电器状态
  init: function(id, key) {
    var that = this
    if (id && key) {
      wx.request({
        url: "https://api.heclouds.com/devices/" + id + "/datapoints", //将请求行中的数字换成自己的设备ID 577429787
        header: {
          "api-key": key //换成自己的api-key N4Hi4scsutQWHiUhVf=y10S6zj4=
        },
        data: {
          limit: 1
        },
        method: "GET",
        success: function(e) {
          // console.log(e.data.data)
          that.setData({
            KG: e.data.data.datastreams[0].datapoints[0].value,
            humidity: e.data.data.datastreams[1].datapoints[0].value,
          })
        },
        fail: function (err) {
          console.log(err)
        },
      });
    }else{
      clearInterval(this.data.myTime)
      wx.showToast({
        title: 'ID和api-key不能为空',
        icon:'none'
      })

    }

  }


})